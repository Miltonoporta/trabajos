/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author HP
 */
public class DAOProveedor {
 
     
    public Proveedor Insertar(int NIF_proveedor, String Nombre,String Apellido,String Direccion, int Telefono) {
    String transaccion = "INSERT INTO Proveedor VALUES('"
            + NIF_proveedor + "', '"
            + Nombre + "', '"
            + Apellido  + "')"
            + Direccion  + "')"
            + Telefono  + "')";
    if (new DataBase().Actualizar(transaccion) > 0) {
        
        return new Proveedor (NIF_proveedor, Nombre, Apellido, Direccion, Telefono);
    }
    return null;
    }
    public int Actualizar(int NIF_proveedor, String Nombre,String Apellido,String Direccion, int Telefono) {
        
        String transaccion = "UPDATE Proveedor SET Nombre='"
               
                + NIF_proveedor + "', NIF_proveedor= '"
                + Nombre+ "', Apellido= '"
                + Apellido+ "', Direccion= '"
                + Direccion+ "',Telefono = '"
                + Telefono+ "'WHERE Telefono_Proveedor=";
                
        
        return new DataBase().Actualizar(transaccion);
    }
    
    public List ObtenerDatos() {
        String transaccion = "SELECT * FROM Proveedores" ;
        List<Map> registros = new DataBase().Listar(transaccion);
        List<Proveedor> proveedores = new ArrayList();
        
        for (Map registro : registros) {
            Proveedor prov = new Proveedor ((int) registro.get("NIF_proveedor"),
                 (String) registro.get("Nombre"),
                 (String) registro.get("Apellido"),
                 (String) registro.get("Direccion"),  
                 (int) registro.get("Telefono"));
            proveedores.add(prov);
        }
        return proveedores;
    }
   
    public int Eliminar(int NIF_proveedor) {
       String transaccion = "DELETE FROM Proveedor WHERE NIF_proveedor='"+ NIF_proveedor+"'";
       
       return new DataBase().Actualizar(transaccion);
    }


    
}
