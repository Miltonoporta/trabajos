/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author HP
 */
import Modelo.*;
import java.util.*;
import java.sql.Date;
import javax.swing.JOptionPane;


public class Productos {
    
    private int codigo_producto;///Debe tener los mismos tipo de datos de la BD
    private String descripcion;
    private int precio;

    //Constructor

    public Productos(int codigo_producto, String descripcion, int precio) {
        this.codigo_producto = codigo_producto;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public int getCodigo_producto() {
        return codigo_producto;
    }

    public void setCodigo_producto(int codigo_producto) {
        this.codigo_producto = codigo_producto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
    
    
}
