/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

 import Modelo.*;
import java.util.*;
import java.sql.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class Venta {
  

    private int ID_venta;
    private String Cedula;
    private int IVA;
   

    public Venta(int ID_venta, String Cedula, int IVA) {
        this.ID_venta = ID_venta;
        this.Cedula = Cedula;
        this.IVA = IVA;
       
    }
    
    
    public int getID_venta() {
        return ID_venta;
    }

    public void setID_venta(int ID_venta) {
        this.ID_venta = ID_venta;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String Cedula) {
        this.Cedula = Cedula;
    }

    public int getIVA() {
        return IVA;
    }

    public void setIVA(int IVA) {
        this.IVA = IVA;
    }

    
}
