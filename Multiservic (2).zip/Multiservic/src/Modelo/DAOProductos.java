
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author HP
 */
public class DAOProductos {
    
    public Productos Insertar(int codigo_producto, int Precio,String descripcion) {
    String transaccion = "INSERT INTO Productos VALUES('"
            + codigo_producto + "', '"
            + Precio + "', '"
            + descripcion  + "')";
            
    if (new DataBase().Actualizar(transaccion) > 0) {
        return new Productos(codigo_producto, descripcion, Precio);
    }        
    return null;
    }
    
    public int Actualizar(int codigo_producto, int Precio, String descripcion ) {
        
        String transaccion = "UPDATE Productos SET nombres='"
               
                + codigo_producto + "', Precio= '"
                + Precio+ "', descripcion= '"
                + descripcion + "' WHERE descripcion_Productos=";
                
        
        return new DataBase().Actualizar(transaccion);
    }
    
    public List ObtenerDatos() {
        String transaccion = "SELECT * FROM Productos" ;
        List<Map> registros = new DataBase().Listar(transaccion);
        List<Productos> productos = new ArrayList();
        
        for (Map registro : registros) {
            Productos prod = new Productos ((int) registro.get("codigo_producto"),
                 (String) registro.get("descripcion"),
                 (int)registro.get("Precio")
                 );
            productos.add(prod);
        }
        return productos;
    }
   
    public int Eliminar(int id) {
       String transaccion = "DELETE FROM Productos WHERE codigo_producto='"+ id +"'";
       
       return new DataBase().Actualizar(transaccion);
    }
}
