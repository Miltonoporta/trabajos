
package Modelo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author HP
 */
public class DAOVenta {
 
   public Venta Insertar(int ID_Venta, String Cedula, int IVA) {
    String transaccion = "INSERT INTO Venta VALUES('"
            + ID_Venta + "', '"
            + Cedula + "','"
            + IVA + "')";
           
            
    if (new DataBase().Actualizar(transaccion) > 0) {
        return new Venta(ID_Venta,Cedula,IVA);
    }        
    return null;
    }
    public int Actualizar(int ID_Venta,String Cedula, int IVA) {
        
        String transaccion = "UPDATE Venta SET nombres='"
               
                + ID_Venta + "', Cedula= '"
                + Cedula   + "',IVA´='"
                + IVA +"' WHERE IVA_Venta='";
              
               
        
        return new DataBase().Actualizar(transaccion);
    }
    
    public List ObtenerDatos() {
        
        String transaccion = "SELECT * FROM Venta" ;
        List<Map> registros = new DataBase().Listar(transaccion);
        List<Venta> Ventas = new ArrayList();
        
        for (Map registro : registros) {
            Venta vent = new Venta((int)registro.get("ID_Venta"),
                 (String) registro.get("Cedula"),
                 (int) registro.get("IVA")
            );
            Ventas.add(vent);
        }
        return Ventas;
    }
   
    public int Eliminar(int ID_Venta) {
       String transaccion = "DELETE FROM Venta WHERE ID_Venta='"+ ID_Venta +"'";
       
       return new DataBase().Actualizar(transaccion);
    }

  

}
  