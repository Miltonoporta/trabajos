/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author HP
 */
import Modelo.*;
import java.util.*;
import java.sql.Date;
import javax.swing.JOptionPane;

public class Compra {

    private int ID_Compra;
    private int precio;
    private String articulo;
    private String cantidad;
    private String abastecedor;

    public Compra() {
    }

    public Compra(int ID_Compra, int precio, String articulo, String cantidad,
            String abastecedor) {
        this.ID_Compra = ID_Compra;
        this.precio = precio;
        this.articulo = articulo;
        this.cantidad = cantidad;
        this.abastecedor = abastecedor;
    }

    public int getID_Compra() {
        return ID_Compra;
    }

    public void setID_Compra(int ID_Compra) {
        this.ID_Compra = ID_Compra;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getArticulo() {
        return articulo;
    }

    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getAbastecedor() {
        return abastecedor;
    }

    public void setAbastecedor(String abastecedor) {
        this.abastecedor = abastecedor;
    }

   
    
    
    


}
