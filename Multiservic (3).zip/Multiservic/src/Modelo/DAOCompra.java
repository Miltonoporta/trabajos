package Modelo;

import java.sql.Date;
import java.util.*;

public class DAOCompra {
    public Compra Insertar(int ID, int Precio, String Articulo,
            String Abastecedor, String Cantidad) {
    String transaccion = "INSERT INTO Compra VALUES('"
            + ID + "', '"
            + Precio + "', '"
            + Articulo + "', '"
            + Abastecedor + "', '"
            + Cantidad  + "')";
            
    if (new DataBase().Actualizar(transaccion) > 0) {
        return new Compra (ID,Precio,Articulo,Abastecedor,Cantidad);
    }        
    return null;
    }
    public int Actualizar(int id, int Precio, String Articulo,
            String Abastecedor, String Cantidad ) {
        
        String transaccion = "UPDATE Compra SET Precio='"
               
                + Precio + "', Articulo= '"
                + Articulo+ "', Abastecedor= '"
                + Abastecedor + "', Cantidad='"
                + Cantidad + "' WHERE ID="
                + id ;
        
        return new DataBase().Actualizar(transaccion);
    }
    
    public List ObtenerDatos() {
        String transaccion = "SELECT * FROM Compra" ;
        List<Map> registros = new DataBase().Listar(transaccion);
        List<Compra> compras = new ArrayList();
        
        for (Map registro : registros) {
            Compra Comp = new Compra ((int) registro.get("ID_Compra"),
                 (Integer.parseInt(registro.get("Precio").toString())),
                 (String) registro.get("apellidos"),
                 (String) registro.get("email"),
                 (String) registro.get("cedula")
                );
            compras.add(Comp);
        }
        return compras;
    }
   
    public int Eliminar(int id) {
       String transaccion = "DELETE FROM Compra WHERE ID_Compra='"+ id +"'";
       
       return new DataBase().Actualizar(transaccion);
    }

  
}
