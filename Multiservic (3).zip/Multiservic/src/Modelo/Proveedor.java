
package Modelo;

/**
 *
 * @author HP
 */
   import Modelo.*;
import java.util.*;
import java.sql.Date;
import javax.swing.JOptionPane;

public class Proveedor {
    private int NIF_proveedor; 
    private String Nombre; 
    private String Apellido;
    private String Direccion;
    private int Telefono;

    public Proveedor(int NIF_proveedor, String Nomnbre, String Apellido, String Direccion, int Telefono) {
        this.NIF_proveedor = NIF_proveedor;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
    }

    public int getNIF_proveedor() {
        return NIF_proveedor;
    }

    public void setNIF_proveedor(int NIF_proveedor) {
        this.NIF_proveedor = NIF_proveedor;
    }

    public String getNomnbre() {
        return Nombre;
    }

    public void setNomnbre(String Nomnbre) {
        this.Nombre = Nomnbre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }
    
    
            
            
            
}
