
CREATE DATABASE MULTISERVIC_BD

	ON ( NAME = MULTISERVIC_BD_data,
	FILENAME = 'C:\BASES DE DATOS\BD_Proyecto.mdf',   
	SIZE = 6,
	MAXSIZE = 10,
	FILEGROWTH = 2 )
	GO 

	CREATE TABLE [Proveedor] (
  [NIF] INT PRIMARY KEY,
  [Nombre] VARCHAR(50),
  [Apellido] VARCHAR(50),
  [Direccion] VARCHAR(150),
  [Telefono] VARCHAR(8)
)
GO

CREATE TABLE [Compra] (
  [ID] INT PRIMARY KEY,
  [Precio] INT,
  [Articulo] VARCHAR(50),
  [Cantidad] INT,
  [Abastecedor] VARCHAR(20),
  [NIF_Proveedor] INT,
  [DNI_Empleado] INT,
  [Codigo_Producto] INT
)
GO

CREATE TABLE [Productos] (
  [Codigo_Producto] INT PRIMARY KEY,
  [Descripcion] VARCHAR(50),
  [Precio] INT
)
GO

CREATE TABLE [Empleado] (
  [DNI] INT PRIMARY KEY,
  [Nombre] VARCHAR(50),
  [Apellido] VARCHAR(50),
  [Telefono] VARCHAR(8)
)
GO

CREATE TABLE [Materia_Prima] (
  [NIF] INT PRIMARY KEY,
  [Fecha_Entrada] DATE,
  [Fecha_Salida] DATE,
  [Cantidad] INT,
  [Descripcion] VARCHAR(80)
)
GO

CREATE TABLE [Venta] (
  [Id_Venta] INT PRIMARY KEY,
  [Cedula] VARCHAR(16),
  [IVA] INT
)
GO

CREATE TABLE [Cliente] (
  [DNI] VARCHAR(16) PRIMARY KEY,
  [Nombre] VARCHAR(50),
  [Apellido] VARCHAR(50),
  [Direccion] VARCHAR(150),
  [Sexo] CHAR(1),
  [Telefono] VARCHAR(8)
)
GO

CREATE TABLE [Producto_Venta] (
  [Id_Producto_Venta] INT PRIMARY KEY,
  [Codigo_Producto] INT,
  [Id_Venta] INT
)
GO

CREATE TABLE [Producto_Materia_Prima] (
  [Id_Producto_Materia_Prima] INT PRIMARY KEY,
  [Codigo_Producto] INT,
  [NIF_Materia_Prima] INT
)
GO

CREATE TABLE [Producto_Compra] (
  [Id_Producto_Compra] INT PRIMARY KEY,
  [Codigo_Producto] INT,
  [ID_Compra] INT
)
GO

ALTER TABLE [Compra] ADD FOREIGN KEY ([NIF_Proveedor]) REFERENCES [Proveedor] ([NIF])
GO

ALTER TABLE [Compra] ADD FOREIGN KEY ([DNI_Empleado]) REFERENCES [Empleado] ([DNI])
GO

ALTER TABLE [Venta] ADD FOREIGN KEY ([Cedula]) REFERENCES [Cliente] ([DNI])
GO

ALTER TABLE [Producto_Venta] ADD FOREIGN KEY ([Codigo_Producto]) REFERENCES [Producto] ([Codigo_Producto])
GO

ALTER TABLE [Producto_Venta] ADD FOREIGN KEY ([Id_Venta]) REFERENCES [Venta] ([Id_Venta])
GO

ALTER TABLE [Producto_Materia_Prima] ADD FOREIGN KEY ([NIF_Materia_Prima]) REFERENCES [Materia_Prima] ([NIF])
GO

ALTER TABLE [Producto_Materia_Prima] ADD FOREIGN KEY ([Codigo_Producto]) REFERENCES [Producto] ([Codigo_Producto])
GO

ALTER TABLE [Producto_Compra] ADD FOREIGN KEY ([Codigo_Producto]) REFERENCES [Producto] ([Codigo_Producto])
GO

ALTER TABLE [Producto_Compra] ADD FOREIGN KEY ([ID_Compra]) REFERENCES [Compra] ([ID])
GO
